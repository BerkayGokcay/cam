# DeepStream 7.1 + YOLOv10‑Face (ONNX) – Linux Kurulum ve Çalıştırma Rehberi

Bu README, Linux (Ubuntu 22.04) üzerinde **YOLOv10‑Face ONNX** modelini **NVIDIA DeepStream 7.1** ile çalıştırmak için uçtan uca adımları içerir. Rehber, NVIDIA’nın **deepstream:7.1‑gc‑triton‑devel** konteyneri içinde test edilmiştir ve **DeepStream‑Yolo** özel ayrıştırıcı (parser) kütüphanesini kullanır.

> Özet akış: Docker + NVIDIA Container Toolkit → DeepStream 7.1 konteyneri → DeepStream‑Yolo derleme → ONNX model ve config → `gst-launch-1.0` veya `deepstream-app` ile RTSP pipeline.

---

## 0) Gereksinimler

* NVIDIA dGPU ve güncel sürücü (CUDA 12.x uyumlu).
* Docker ve **NVIDIA Container Toolkit**.
* RTSP kaynağı (H.264/H.265).
* X11 görüntüleme için yerel masaüstü (isteğe bağlı – başsız modda `fakesink` de kullanılabilir).

---

## 1) Docker ve NVIDIA Container Toolkit

### 1.1 Docker kurulumu (Ubuntu)

```bash
sudo apt-get update
sudo apt-get install -y ca-certificates curl gnupg lsb-release
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
  $(lsb_release -cs) stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
sudo apt-get update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io
sudo usermod -aG docker "$USER"
newgrp docker
```

### 1.2 NVIDIA Container Toolkit

```bash
curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | \
  sudo gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg
curl -fsSL https://nvidia.github.io/libnvidia-container/$(. /etc/os-release; echo $ID$VERSION_ID)/libnvidia-container.list | \
  sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#' | \
  sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list > /dev/null
sudo apt-get update
sudo apt-get install -y nvidia-container-toolkit
sudo nvidia-ctk runtime configure --runtime=docker
sudo systemctl restart docker || true
```

> `systemd` olmayan ortamlarda (ör. WSL) `dockerd` yeniden başlatma komutları farklı olabilir.

### 1.3 GPU görünürlüğünü test edin

```bash
docker run --rm --gpus all nvidia/cuda:12.6.0-base-ubuntu22.04 nvidia-smi
```

---

## 2) DeepStream 7.1 geliştirici konteynerini başlatma

### 2.1 Konteyneri çekin

```bash
docker pull nvcr.io/nvidia/deepstream:7.1-gc-triton-devel
```

### 2.2 X11 (görüntülü) çalıştırma örneği

```bash
# Ekran yetkisi (host tarafında)
xhost +local:root

# Konteyneri başlatın
export DISPLAY=${DISPLAY:-:0}
GUI_MOUNTS="-e DISPLAY=$DISPLAY -v /tmp/.X11-unix:/tmp/.X11-unix:rw"

MODEL_DIR=/opt/models  # hostta model klasörü
mkdir -p "$MODEL_DIR"

docker run -it --rm --gpus all \
  --net=host \
  $GUI_MOUNTS \
  -v "$MODEL_DIR":/opt/models \
  nvcr.io/nvidia/deepstream:7.1-gc-triton-devel
```

> Bash’te `!` karakteri history expansion’a yol açar. Pipeline komutlarında `!` için **`\!`** kullanın veya `set +H` ile history expansion’ı kapatın.

### 2.3 (İsteğe bağlı) Eksik GStreamer eklentileri

DeepStream konteynerleri lisans nedeniyle bazı OSS/GPL eklentileri içermez. Uyarıları azaltmak için:

```bash
/opt/nvidia/deepstream/deepstream/user_additional_install.sh
# veya
apt-get update && apt-get install -y \
  gstreamer1.0-plugins-good gstreamer1.0-plugins-bad \
  gstreamer1.0-plugins-ugly gstreamer1.0-libav
```

---

## 3) DeepStream‑Yolo kütüphanesini derleme

Konteyner içinde:

```bash
cd /opt
git clone https://github.com/marcoslucianops/DeepStream-Yolo.git
cd DeepStream-Yolo

# DeepStream 7.1 için gerekli CUDA sürümü eşlemesi
export CUDA_VER=12.6

make -C nvdsinfer_custom_impl_Yolo clean && \
make -C nvdsinfer_custom_impl_Yolo
```

Derleme sonunda çıktınız:

```
/opt/DeepStream-Yolo/nvdsinfer_custom_impl_Yolo/libnvdsinfer_custom_impl_Yolo.so
```

---

## 4) Model dosyalarını yerleştirme

Elinizdeki **YOLOv10‑Face ONNX** dosyasını hostta `/opt/models/yolov10_face/yolov10n-face.onnx` olarak konumlandırın ve konteynerde bu yola erişin.

```bash
mkdir -p /opt/models/yolov10_face
# (Hosttan kopyaladıysanız bu adım gerekmez)
# cp <host_path>/yolov10n-face.onnx /opt/models/yolov10_face/

echo "face" > /opt/models/yolov10_face/labels.txt
```

> ONNX giriş/çıkış bağ adlarını doğrulamak için:
>
> ```bash
> trtexec --onnx=/opt/models/yolov10_face/yolov10n-face.onnx \
>         --shapes=images:1x3x640x640 --verbose --dumpProfile --noDataTransfers
> ```
>
> Çoğu Ultralytics tabanlı ONNX’ta giriş `images`, çıktı `output0` olur. Yüz modeli farklıysa `output-blob-names` değerini çıktıyla eşleştirin.

---

## 5) `nvinfer` konfigürasyonu (YOLOv10‑Face)

`/opt/models/yolov10_face/pgie_yolov10_face_ds71.txt`

```ini
[property]
# Genel
gpu-id=0
enable=1
unique-id=1
process-mode=1
network-type=0              # 0: detector
batch-size=1

# ONNX / TensorRT
onnx-file=/opt/models/yolov10_face/yolov10n-face.onnx
model-engine-file=/opt/models/yolov10_face/yolov10n-face_b1_gpu0_fp16.engine
network-mode=2              # 0:FP32, 1:INT8, 2:FP16
#int8-calib-file=/opt/models/yolov10_face/calib.table

# Girdi boyutu ve renk
infer-dims=3;640;640        # modeliniz 640x640 ise; farklıysa güncelleyin
model-color-format=0        # 0=RGB, 1=BGR, 2=GRAY
net-scale-factor=0.003921568627

# Çıktı bağ adı (gerekirse değiştirin)
output-blob-names=output0

# Etiketler
labelfile-path=/opt/models/yolov10_face/labels.txt
num-detected-classes=1

# Letterbox (YOLO gibi modeller için önerilir)
maintain-aspect-ratio=1
symmetric-padding=1

# YOLO özel ayrıştırıcı
custom-lib-path=/opt/DeepStream-Yolo/nvdsinfer_custom_impl_Yolo/libnvdsinfer_custom_impl_Yolo.so
parse-bbox-func-name=NvDsInferParseYolo
# (Alternatif CUDA parser) parse-bbox-func-name=NvDsInferParseYoloCuda

# Çalışma alanı (isteğe bağlı)
#workspace-size=2000

[class-attrs-all]
# NMS/threshold ayarları burada olmalı
nms-iou-threshold=0.45
pre-cluster-threshold=0.25
topk=300
```

> Notlar
>
> * `pre-cluster-threshold`, `nms-iou-threshold`, `topk` **\[class-attrs-all]** altında olmalıdır; \[property] altında yazılırsa “Unknown or legacy key” uyarısı alırsınız.
> * YOLOv10, NMS‑free eğitimi destekler. DeepStream tarafında yine de NMS kümeleme uygulanır; çift kutu (duplicate) görürseniz `nms-iou-threshold` ve `pre-cluster-threshold` değerlerini ayarlayın veya takipçi (tracker) IOU eşiklerini sıkılaştırın.

### 5.1 Bağ adları farklıysa

* Girdi adı `images` değilse, `input-blob-name` ekleyin: `input-blob-name=<ad>`
* Birden çok çıktı varsa: `output-blob-names=out1;out2`
* Adları `trtexec` çıktısına göre güncelleyin.

---

## 6) Hızlı test – `gst-launch-1.0` (RTSP → Infer → OSD → X11)

> Bash’te `!` kaçışını unutmayın: komuttan önce `set +H` çalıştırın **ya da** her `!` karakterini `\!` ile kaçışlayın.

```bash
set +H

gst-launch-1.0 \
  rtspsrc location="rtsp://USER:PASS@HOST:PORT/" latency=200 \
    \! rtph264depay \! h264parse \! nvv4l2decoder \
    \! nvvideoconvert \! "video/x-raw(memory:NVMM),format=NV12" \
    \! queue \! m.sink_0 \
  nvstreammux name=m batch-size=1 width=1280 height=720 live-source=true batched-push-timeout=40000 \
    \! nvinfer config-file-path=/opt/models/yolov10_face/pgie_yolov10_face_ds71.txt \
    \! nvdsosd process-mode=1 \! nvvideoconvert \! videoconvert \! ximagesink sync=false
```

Başsız (headless) modda test etmek için son kısmı `fakesink sync=false` ile değiştirebilirsiniz.

---

## 7) `deepstream-app` ile çalıştırma (isteğe bağlı)

`/opt/models/yolov10_face/deepstream_app_config.txt`

```ini
[application]
enable-perf-measurement=1
perf-measurement-interval-sec=5

[tiled-display]
enable=1
rows=1
columns=1
width=1280
height=720
gpu-id=0

[source0]
enable=1
type=4                  # RTSP
uri=rtsp://USER:PASS@HOST:PORT/stream
num-sources=1
gpu-id=0
cudadec-memtype=0

[streammux]
live-source=1
batch-size=1
batched-push-timeout=40000
width=1280
height=720

[primary-gie]
enable=1
gpu-id=0
model-engine-file=/opt/models/yolov10_face/yolov10n-face_b1_gpu0_fp16.engine
config-file=/opt/models/yolov10_face/pgie_yolov10_face_ds71.txt

[osd]
enable=1
process-mode=1

enable-padding=0

[sink0]
enable=1
type=3                  # EGL/X11 görüntü
sync=0
```

Çalıştırma:

```bash
deepstream-app -c /opt/models/yolov10_face/deepstream_app_config.txt
```

---

## 8) Tanılama ve sık görülen hatalar

### 8.1 `!` nedeniyle sözdizimi hatası / `command not found`

* Çözüm: `set +H` veya `\!` kaçışı.

### 8.2 `Unknown or legacy key ...`

* `pre-cluster-threshold`, `nms-iou-threshold`, `topk` gibi anahtarlar **\[class-attrs-all]** bölümünde olmalı.

### 8.3 `UFF model support has been deprecated`

* DeepStream 7.1 (TensorRT 10.x) ile **UFF/ETLT** desteklenmez. ONNX’e geçin.

### 8.4 Engine oluşturma uzun sürüyor

* İlk çalıştırmada TensorRT motoru derlenir. Aynı `model-engine-file` ile sonraki çalıştırmalar hızlıdır.
* Ayrıntılı günlük için: `export NVDSINFER_LOG_LEVEL=3`.

### 8.5 `nvv4l2decoder` codec desteği

* H.264/H.265/AV1/JPEG/MJPEG akışlar desteklenir. AV1 için sürüm desteği gereklidir.

### 8.6 X11 / EGL hataları

* Host’ta `xhost +local:root` verin.
* Konteynerde `DISPLAY` ve `/tmp/.X11-unix` mount edildiğinden emin olun.

### 8.7 YOLOv10’da çift kutular (duplicate)

* `nms-iou-threshold`u düşürün (ör. 0.45 → 0.4).
* `pre-cluster-threshold`u yükseltin/düşürün (ör. 0.25 ↔ 0.35) ve FPS/accuracy dengesini gözleyin.
* Takipçi (IOU/DCF/DeepSORT) ile birleşik filtreleme düşünün.

---

## 9) Performans ipuçları

* **network-mode**: FP16 genellikle iyi bir denge sunar. INT8 için yeni kalibrasyon dosyası üretmeniz gerekir.
* **batch-size**: RTSP tek kaynak ise 1. Çoklu kaynakta `nvstreammux.batch-size` ve `nvinfer.batch-size` eşleşmeli.
* **batched-push-timeout**: Mikro-saniye cinsinden. Canlı kaynaklarda gecikme ile FPS arasında denge kurun (ör. 40000 = 40 ms).
* **maintain-aspect-ratio + symmetric-padding**: Letterbox girişleri için doğruluğu artırır.

---

## 10) Dizin yapısı (öneri)

```
/opt/models/
└── yolov10_face/
    ├── yolov10n-face.onnx
    ├── labels.txt
    ├── pgie_yolov10_face_ds71.txt
    ├── yolov10n-face_b1_gpu0_fp16.engine   # (oluşur)
    └── deepstream_app_config.txt           # (isteğe bağlı)

/opt/DeepStream-Yolo/
└── nvdsinfer_custom_impl_Yolo/
    └── libnvdsinfer_custom_impl_Yolo.so
```

---

## 11) Sürüm notları

* Bu rehber DeepStream 7.1 konteyneri (TensorRT 10.x) hedef alınarak hazırlanmıştır.
* Daha eski TensorRT/DeepStream ile üretilen engine/kalibrasyon dosyaları 7.1/10.x ile **uyumlu değildir**; yeniden oluşturmanız gerekir.

---

## 12) Ekler

### 12.1 `deepstream-app` yerine yalnızca `gst-launch-1.0` kullanımı

`deepstream-app`, yapılandırması kolay bir referans uygulamasıdır. Geliştirme sırasında boru hattını parça parça görmek için `gst-launch-1.0` ile test etmek faydalıdır. Yukarıdaki tek satırlık komut çoğu RTSP kaynağı için yeterlidir.

### 12.2 Tracker eklemek (opsiyonel örnek)

`iou` tabanlı basit bir takipçi için `nvtracker` ekleyebilirsiniz:

```bash
... \
  \! nvinfer config-file-path=/opt/models/yolov10_face/pgie_yolov10_face_ds71.txt \
  \! nvtracker tracker-width=640 tracker-height=384 ll-lib-file=/opt/nvidia/deepstream/deepstream/lib/libnvds_nvmultiobjecttracker.so ll-config-file=/opt/nvidia/deepstream/deepstream/samples/configs/deepstream-app/config_tracker_IOU.yml \
  \! nvdsosd process-mode=1 ...
```

Parametreleri sahnenize göre ayarlayın.

---

## 13) Lisans

* DeepStream-Yolo: MIT
* NVIDIA DeepStream SDK: NVIDIA lisans koşulları
* Kullanılan paket ve modeller ilgili lisanslarına tabidir.
