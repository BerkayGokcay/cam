Harika — artık **PGIE (YOLOv10 yüz tespiti) + SGIE (ArcFace / webface\_r50 gömme)** ile canlı RTSP akışından embedding çıkarabiliyorsunuz. Şimdi bunu *uçtan uca* bir sisteme dönüştürelim: canlı/video ve resim girişleri, gömme üretimi, veritabanında arama, eşikleme, ve dış dünyaya API ile cevap.

Aşağıdaki plan; **DeepStream 7.1** (Docker), **SGIE tensor meta okuma (PyDS)**, **PostgreSQL + pgvector** ya da **FAISS** ile benzerlik araması ve **FastAPI** tabanlı servis mimarisini içerir.

---

## 1) Mimarinin özeti

1. **Girişler**

   * Canlı RTSP akışları (N adet).
   * Dosyadan video / tek resim.
2. **DeepStream boru hattı**

   * `rtspsrc → ... → nvstreammux → nvinfer(pgie: yüz) → nvtracker → nvinfer(sgie: arcface) → nvdsosd → sink`
   * SGIE’de `output-tensor-meta=1` ile 512-boyutlu embedding’ler metadata olarak eklenir. ([NVIDIA Docs][1])
3. **Python (PyGObject + pyds)**

   * `nvdsosd` öncesi pad-probe:

     * SGIE `NvDsInferTensorMeta` al, tensoru **L2 normalize et**, kimlik veritabanına gönder. ArcFace gömmeleri 512-boyutludur ve kosinüs benzerliğiyle karşılaştırılır. ([arXiv][2], [OpenVINO Documentation][3])
4. **Veritabanı katmanı**

   * **Seçenek A – PostgreSQL + pgvector**: Kolay yönetim, ACID, JOIN vb. `<=>` ile kosinüs mesafesi; benzerlik = `1 - mesafe`. HNSW veya IVFFlat indeksleriyle hızlı arama. ([GitHub][4])
   * **Seçenek B – FAISS**: Çok büyük koleksiyonlarda GPU hızlandırmalı ANN. Kosinüs için vektörleri L2 normalize edip **inner product** metriğiyle indeksle. ([Faiss][5], [GitHub][6])
5. **Eşikleme**

   * ArcFace için normalize edilmiş gömmelerde **kosinüs benzerliği** kullanın; başlangıç için pratik aralık **0.35–0.5** (verinizde kalibre edin). Literatürde 512-d ArcFace gömmeleri ve kosinüs benzerliği standarttır; LFW gibi setlerde yüksek doğruluk elde edilir, fakat üretimde eşik kurum içi doğrulamayla seçilmelidir. ([arXiv][2], [OpenVINO Documentation][3], [LearnOpenCV][7], [Reddit][8])
6. **Dışa açılan API**

   * **FastAPI**:

     * `/enroll` — bir kimliğe ait 1..K yüz embedding’i ekle.
     * `/match` — gelen embedding’e en yakın K aday + skorları döndür.
     * `/healthz` — sağlık kontrolü.

---

## 2) DeepStream boru hattı

### 2.1. GStreamer komutu (çalıştırdığınız biçime çok yakın)

```bash
gst-launch-1.0 \
  rtspsrc location="rtsp://USER:PASS@HOST:PORT/..." latency=200 !
  rtph264depay ! h264parse ! nvv4l2decoder !
  nvvideoconvert ! "video/x-raw(memory:NVMM),format=NV12" ! queue ! m.sink_0 \
  nvstreammux name=m batch-size=1 width=1280 height=720 live-source=true batched-push-timeout=40000 !
  nvinfer name=pgie unique-id=1 batch-size=1 \
          config-file-path=/opt/models/yolov10_face/pgie_yolov10_face.txt !
  nvtracker ll-lib-file=/opt/nvidia/deepstream/deepstream/lib/libnvds_nvmultiobjecttracker.so \
            tracker-width=640 tracker-height=368 gpu-id=0 \
            enable-past-frame=1 ! \
  nvinfer name=sgie unique-id=2 process-mode=2 \
          config-file-path=/opt/models/recognition/sgie_arcface.txt !
  nvdsosd process-mode=1 !
  nvvideoconvert ! videoconvert ! ximagesink sync=false
```

* `nvtracker` takibi sayesinde SGIE sonuçları nesne **ID**’leriyle ilişkilendirilir; tekrar tekrar aynı yüzden embedding almak yerine aralıklı örnekleme veya skor birleştirme yapabilirsiniz. ([NVIDIA Docs][9], [Edge AI and Vision Alliance][10])

### 2.2. SGIE (ArcFace) konfigürasyonu (özet)

`/opt/models/recognition/sgie_arcface.txt`:

```ini
[property]
gpu-id=0
process-mode=2                 # secondary
gie-unique-id=2
operate-on-gie-id=1
operate-on-class-ids=0         # PGIE yüz sınıfı
network-type=1                 # classifier
batch-size=1

# Giriş (ArcFace / webface_r50)
model-color-format=0           # RGB
infer-dims=3;112;112
net-scale-factor=0.0078125     # 1/128
offsets=127.5;127.5;127.5

# Model
onnx-file=/opt/models/recognition/webface_r50.onnx
model-engine-file=/opt/models/recognition/webface_r50.onnx_b1_gpu0_fp32.engine

# Çıktı
output-tensor-meta=1
# output-blob-names=fc1        # gerekirse ONNX çıkış adı
```

* `output-tensor-meta=1` ile **NvDsInferTensorMeta** eklenir; SGIE ise nesne bazında bu metayı `obj_user_meta_list` içinde taşır. ([NVIDIA Docs][1])
* ArcFace giriş boyutu 112×112 RGB, çıkış **512-float** vektördür; kosinüs benzerliği ile karşılaştırılır. ([arXiv][2], [OpenVINO Documentation][3], [Medium][11])

---

## 3) Embedding’i terminalde görmek (hızlı doğrulama)

Aşağıdaki minimal Python, `sgie` çıkışını yakalar, **L2 normalize eder** ve ilk birkaç değeri ve normu yazdırır.

> Not: DeepStream 7.1 ile **PyDS/NumPy sürümü uyumluluğu** önemlidir; NVIDIA, NumPy 2.x’in desteklenmediğini, belirli tekerlerin kullanılmasını ve pyds’nin resmi sürümlerini önerir. Konteynerinizdeki sürümler uyumlu görünüyor; yine de çakışma yaşarsanız DS 7.1 sürüm notlarındaki yönergeleri izleyin. ([NVIDIA Docs][12])

```python
#!/usr/bin/env python3
import gi, math, numpy as np
gi.require_version("Gst", "1.0")
from gi.repository import Gst, GObject
import pyds

Gst.init(None)

PIPE = r'''
rtspsrc location="rtsp://USER:PASS@HOST:PORT/..." latency=200 !
rtph264depay ! h264parse ! nvv4l2decoder !
nvvideoconvert ! "video/x-raw(memory:NVMM),format=NV12" ! queue ! m.sink_0
nvstreammux name=m batch-size=1 width=1280 height=720 live-source=true batched-push-timeout=40000 !
nvinfer name=pgie unique-id=1 config-file-path=/opt/models/yolov10_face/pgie_yolov10_face.txt !
nvtracker ll-lib-file=/opt/nvidia/deepstream/deepstream/lib/libnvds_nvmultiobjecttracker.so tracker-width=640 tracker-height=368 enable-past-frame=1 !
nvinfer name=sgie unique-id=2 process-mode=2 config-file-path=/opt/models/recognition/sgie_arcface.txt !
nvdsosd !
fakesink sync=false
'''

def l2norm(v):
    n = np.linalg.norm(v)
    return v / n if n > 0 else v

def osd_sink_pad_buffer_probe(pad, info, u_data):
    buf = info.get_buffer()
    if not buf:
        return Gst.PadProbeReturn.OK

    batch_meta = pyds.gst_buffer_get_nvds_batch_meta(hash(buf))
    l_frame = batch_meta.frame_meta_list
    while l_frame:
        frame_meta = pyds.NvDsFrameMeta.cast(l_frame.data)
        l_obj = frame_meta.obj_meta_list
        while l_obj:
            obj = pyds.NvDsObjectMeta.cast(l_obj.data)
            # SGIE tensor meta obj_user_meta_list'te
            l_user = obj.obj_user_meta_list
            while l_user:
                user_meta = pyds.NvDsUserMeta.cast(l_user.data)
                if user_meta.base_meta.meta_type == pyds.NvDsMetaType.NVDSINFER_TENSOR_OUTPUT_META:
                    tensor_meta = pyds.NvDsInferTensorMeta.cast(user_meta.user_meta_data)
                    # İlk layer'ı al (fc1)
                    layer = pyds.get_nvds_LayerInfo(tensor_meta, 0)
                    ptr = pyds.get_ptr(layer.buffer)
                    # 512 float bekleniyor
                    out = np.frombuffer(pyds.ffi.buffer(ptr, layer.inferDims.numElements * 4), dtype=np.float32)
                    emb = l2norm(out)
                    print(f"frame {frame_meta.frame_num} obj_id {obj.object_id} len={emb.size} norm={np.linalg.norm(emb):.4f} head={emb[:5]}")
                l_user = l_user.next
            l_obj = l_obj.next
        l_frame = l_frame.next
    return Gst.PadProbeReturn.OK

def main():
    pipeline = Gst.parse_launch(PIPE)
    osd = pipeline.get_by_name("nvdsosd0") or pipeline.get_by_name("nvdsosd")
    sinkpad = osd.get_static_pad("sink")
    sinkpad.add_probe(Gst.PadProbeType.BUFFER, osd_sink_pad_buffer_probe, None)
    pipeline.set_state(Gst.State.PLAYING)
    loop = GObject.MainLoop()
    try:
        loop.run()
    except KeyboardInterrupt:
        pass
    pipeline.set_state(Gst.State.NULL)

if __name__ == "__main__":
    main()
```

* Çıktıda `len=512` ve `norm≈1.0` görmelisiniz. Bu, embedding üretiminin doğru olduğunu gösterir.
* Tensor meta yerleşimi ve erişimi için NVIDIA’nın `Gst-nvinfer` dökümantasyonu referanstır. ([NVIDIA Docs][1])

---

## 4) Veritabanı: pgvector (önerilen)

### 4.1. Kurulum & şema

```sql
-- pgvector
CREATE EXTENSION IF NOT EXISTS vector;

-- Kişiler
CREATE TABLE persons (
  person_id   bigserial PRIMARY KEY,
  external_id text UNIQUE,          -- opsiyonel
  full_name   text
);

-- Yüz embedding’leri
CREATE TABLE face_embeddings (
  emb_id      bigserial PRIMARY KEY,
  person_id   bigint REFERENCES persons(person_id),
  src         text,                 -- rtsp url, dosya, kamera vs.
  ts          timestamptz DEFAULT now(),
  quality     real,                 -- yüz alanı, keskinlik vb. skor ekleyebilirsiniz
  embedding   vector(512) NOT NULL
);

-- Hızlı arama için HNSW (veya IVFFlat) - kosinüs
CREATE INDEX ON face_embeddings USING hnsw (embedding vector_cosine_ops);
-- Alternatif: IVFFlat
-- CREATE INDEX face_emb_ivf ON face_embeddings USING ivfflat (embedding vector_cosine_ops) WITH (lists=100);
```

* Sorgu (en yakın 5 kişi):

```sql
-- q : 512-float JSON veya array
WITH q(v) AS (
  SELECT '[0.1, 0.2, ... , 0.3]'::vector
)
SELECT fe.person_id,
       1 - (fe.embedding <=> q.v) AS cosine_sim,  -- benzerlik
       fe.emb_id, fe.ts
FROM face_embeddings fe, q
ORDER BY fe.embedding <=> q.v    -- küçük mesafe = daha benzer
LIMIT 5;
```

* Cosine distance operatörü `<=>`, benzerlik elde etmek için `1 - distance` kullanın. HNSW/IVFFlat indeksleri desteklenir. ([GitHub][4])

### 4.2. FAISS (çok büyük veri için)

* Vektörleri **L2 normalize edin** ve **METRIC\_INNER\_PRODUCT** ile indeksleyin; böylece iç-çarpım = kosinüs benzerliği olur. ([GitHub][6])

---

## 5) Eşik seçimi (threshold)

* ArcFace gömmeleri için **L2 normalize + kosinüs benzerliği** standarttır. Başlangıç eşiği olarak **0.35–0.50** aralığı pratikte kullanılır; ancak **kendi verinizde** kalibrasyon şart:

  1. Pozitif (aynı kişi) ve negatif (farklı kişi) çiftlerinden bir doğrulama seti hazırlayın.
  2. Her çift için kosinüs benzerliği hesaplayın.
  3. Hedef **FAR** (ör. %0.1) altında **TAR**’ı maksimize eden eşiği, veya **Youden/F1** optimumunu seçin.
* LFW/InsightFace çalışmaları 512-d ArcFace ile yüksek doğruluk ve kosinüs benzerliği kullanımını rapor eder; üretimde dağıtım koşulları (açı, ışık, çözünürlük) nedeniyle daha **yüksek eşik** gerekebilir. ([arXiv][2], [OpenVINO Documentation][3], [LearnOpenCV][7], [Reddit][8])

---

## 6) Servis katmanı (FastAPI)

* DeepStream uygulaması içinde (aynı konteyner) bir HTTP istemcisiyle Postgres’e yazmak en basitidir. Alternatif olarak **nvmsgbroker** ile Kafka/MQTT’ye olay yayıp, ayrı bir **worker** gömme ve eşleştirme işlemlerini yapabilir. ([NVIDIA Docs][13])

### 6.1. Minimal FastAPI sunucusu (pgvector ile)

```python
# server.py
from fastapi import FastAPI
from pydantic import BaseModel
import asyncpg, os

app = FastAPI()
DSN = os.getenv("PG_DSN", "postgresql://user:pass@localhost:5432/faces")

class Enroll(BaseModel):
    person_id: int
    embedding: list[float]  # 512

class MatchReq(BaseModel):
    embedding: list[float]
    topk: int = 5

@app.on_event("startup")
async def startup():
    app.state.db = await asyncpg.connect(DSN)

@app.post("/enroll")
async def enroll(e: Enroll):
    db = app.state.db
    # normalize
    import numpy as np
    v = np.array(e.embedding, dtype="float32")
    v = v / max(np.linalg.norm(v), 1e-9)
    await db.execute(
        "INSERT INTO face_embeddings(person_id, embedding) VALUES ($1, $2)",
        e.person_id, v.tolist()
    )
    return {"ok": True}

@app.post("/match")
async def match(m: MatchReq):
    import numpy as np
    v = np.array(m.embedding, dtype="float32")
    v = v / max(np.linalg.norm(v), 1e-9)
    rows = await app.state.db.fetch(
        """
        SELECT person_id, emb_id, 1 - (embedding <=> $1) AS sim
        FROM face_embeddings
        ORDER BY embedding <=> $1
        LIMIT $2
        """,
        v.tolist(), m.topk
    )
    return [dict(r) for r in rows]
```

* DeepStream pad-probe içinde `requests.post("http://127.0.0.1:8000/match", json=...)` çağırabilirsiniz.
* `nvmsgbroker` kullanmak isterseniz, Kafka/MQTT örnekleri için NVIDIA dokümantasyonunu inceleyin. ([NVIDIA Docs][13])

---

## 7) Dosyadan video / tek resim

* **Video dosyası**: `filesrc location=... ! decodebin ! nvvideoconvert ! ...` ve `live-source=false` ile `nvstreammux`.
* **Tek resim**: En kolayı, resmi önce bir kereye mahsus **ONNXRuntime/TensorRT** ile dışarıda çalıştırıp embedding üretmek; fakat aynı DS hattını kullanmak isterseniz resmi kısa bir MP4’e veya tek karelik bir `imagefreeze` pipeline’ına dönüştürebilirsiniz. (DS resmi videoya kıyasla yönetmeyi seviyor.) Bu yaklaşım pratikte yaygındır. Bu tür dönüşümlerde SGIE/PGIE konfigleri değişmez; giriş tarafı farklılaşır. NVIDIA `Gst-nvinfer` belgeleri, aynı konfig ile farklı kaynakların desteklendiğini belirtir. ([NVIDIA Docs][1])

---

## 8) Motor (.engine) önbellekleme

* Konfigdeki `model-engine-file` yolunu **persist** bir volume’a koyun (`-v /mnt/engines:/opt/models/...`) ki konteyner her açılışta motoru yeniden derlemesin. DeepStream, önce dosyadan deserializasyonu dener; bulunamazsa modelden derler ve kaydeder. ([NVIDIA Docs][1])

---

## 9) Ölçekleme ve istenirse Triton

* Çok sayıda kamera veya model varyasyonu için, `nvinferserver` ile **Triton Inference Server** kullanabilirsiniz. DeepStream 7.1 konteyneri Triton 2.49.0 içeriyor ve model repository üzerinden yükleme yapıyor. Sizin önceki hatanız, model klasöründe **en az bir sürüm dizini (1/)** ve içinde model dosyası olmamasından kaynaklanıyordu. ([NVIDIA Docs][14], [Medium][15])

---

## 10) Bir sonraki adımlar

1. **Pad-probe ➜ FastAPI** entegrasyonunu ekleyelim (istiyorsanız ben yazayım).
2. **Eşik kalibrasyonu** için küçük bir doğrulama seti oluşturun; ben bu seti kullanarak ROC eğrisi, FAR/TAR tablolarını çıkarırım. ([LearnOpenCV][7])
3. **pgvector** kurup tablo ve indeksleri oluşturun. Performans gerekirse **HNSW** kullanın. ([GitHub][4])
4. **Tracker ayarı**: NvDCF için `config_tracker_NvDCF*.yml` dosyalarından birini temel alın; ID kararlılığı ve gecikme arasında denge kurun. ([NVIDIA Docs][9], [NVIDIA Docs][16])

İsterseniz şimdi pad-probe içinden FastAPI’ye istek atan kısa bir örnekle devam edeyim. Ayrıca Postgres bağlantısı ve pgvector sorgularının tamamını da hazırlarım. Ne taraftan başlayalım?

[1]: https://docs.nvidia.com/metropolis/deepstream/dev-guide/text/DS_plugin_gst-nvinfer.html "Gst-nvinfer — DeepStream documentation"
[2]: https://arxiv.org/pdf/1801.07698?utm_source=chatgpt.com "[PDF] ArcFace: Additive Angular Margin Loss for Deep Face Recognition"
[3]: https://docs.openvino.ai/2023.3/omz_models_model_face_recognition_resnet100_arcface_onnx.html?utm_source=chatgpt.com "face-recognition-resnet100-arcface-onnx"
[4]: https://github.com/pgvector/pgvector "GitHub - pgvector/pgvector: Open-source vector similarity search for Postgres"
[5]: https://faiss.ai/?utm_source=chatgpt.com "Welcome to Faiss Documentation — Faiss documentation"
[6]: https://github.com/facebookresearch/faiss/wiki/MetricType-and-distances?utm_source=chatgpt.com "MetricType and distances · facebookresearch/faiss Wiki - GitHub"
[7]: https://learnopencv.com/face-recognition-with-arcface/?utm_source=chatgpt.com "Face Recognition with ArcFace - LearnOpenCV"
[8]: https://www.reddit.com/r/deeplearning/comments/1ib4c52/help_debugging_arcface_performance_on_lfw_dataset/?utm_source=chatgpt.com "Help Debugging ArcFace Performance on LFW Dataset (Stuck at ..."
[9]: https://docs.nvidia.com/metropolis/deepstream/dev-guide/text/DS_plugin_gst-nvtracker.html?utm_source=chatgpt.com "Gst-nvtracker — DeepStream documentation - NVIDIA Docs Hub"
[10]: https://www.edge-ai-vision.com/2022/06/nvidia-deepstream-technical-deep-dive-multi-object-tracker/?utm_source=chatgpt.com "NVIDIA DeepStream Technical Deep Dive: Multi-object Tracker"
[11]: https://medium.com/apache-mxnet/onnx-model-zoo-developing-a-face-recognition-application-with-onnx-models-64eeeddb9c7a?utm_source=chatgpt.com "ONNX Model Zoo: Developing a face recognition application with ..."
[12]: https://docs.nvidia.com/metropolis/deepstream/DeepStream_7.1_Release_Notes.pdf?utm_source=chatgpt.com "[PDF] DeepStream SDK 7.1 for NVIDIA dGPU/X86 and Jetson"
[13]: https://docs.nvidia.com/metropolis/deepstream/dev-guide/text/DS_plugin_gst-nvmsgbroker.html?utm_source=chatgpt.com "Gst-nvmsgbroker — DeepStream documentation - NVIDIA Docs Hub"
[14]: https://docs.nvidia.com/metropolis/deepstream/dev-guide/text/DS_plugin_gst-nvinferserver.html?utm_source=chatgpt.com "Gst-nvinferserver — DeepStream documentation - NVIDIA Docs Hub"
[15]: https://medium.com/data-science/building-an-image-similarity-search-engine-with-faiss-and-clip-2211126d08fa?utm_source=chatgpt.com "Building an Image Similarity Search Engine with FAISS and CLIP"
[16]: https://docs.nvidia.com/metropolis/deepstream/6.3/dev-guide/text/DS_plugin_gst-nvtracker.html?utm_source=chatgpt.com "Gst-nvtracker — DeepStream 6.3 Release documentation"
